const request = require('supertest');
const app = require('../src/app');

describe('Complaints API', () => {
  let studentToken;
  let adminToken;
  let complaintId;

  beforeAll(async () => {
    const student = await request(app).post('/api/auth/register').send({
      name: 'Complaint Student',
      email: 'complaint.student@test.com',
      password: 'password123',
    });
    studentToken = student.body.token;

    const admin = await request(app).post('/api/auth/register').send({
      name: 'Admin User',
      email: 'admin1@test.com',
      password: 'password123',
      role: 'admin',
    });
    adminToken = admin.body.token;
  });

  it('rejects unauthenticated complaint creation', async () => {
    const res = await request(app).post('/api/complaints').send({ title: 'x', description: 'y' });
    expect(res.status).toBe(401);
  });

  it('creates a complaint with default category/priority when not provided', async () => {
    const res = await request(app)
      .post('/api/complaints')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({
        title: 'Water leakage near Lab 2',
        description: 'There is a water pipe leaking near the entrance of Lab 2',
        building: 'Building A',
        room: '204',
      });

    expect(res.status).toBe(201);
    expect(res.body.complaint.category).toBe('Uncategorized');
    expect(res.body.complaint.priority).toBe('Medium');
    expect(res.body.complaint.status).toBe('Open');
    complaintId = res.body.complaint.id;
  });

  it('accepts an explicit category/priority on creation', async () => {
    const res = await request(app)
      .post('/api/complaints')
      .set('Authorization', `Bearer ${studentToken}`)
      .send({
        title: 'Broken projector',
        description: 'Projector in Room 305 does not turn on',
        category: 'IT/Network',
        priority: 'High',
      });

    expect(res.status).toBe(201);
    expect(res.body.complaint.category).toBe('IT/Network');
    expect(res.body.complaint.priority).toBe('High');
  });

  it('lets an admin update category/priority via the classification endpoint', async () => {
    const res = await request(app)
      .patch(`/api/complaints/${complaintId}/classification`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ category: 'Plumbing', priority: 'High' });

    expect(res.status).toBe(200);
    expect(res.body.complaint.category).toBe('Plumbing');
    expect(res.body.complaint.priority).toBe('High');
  });

  it('blocks a student from using the classification endpoint', async () => {
    const res = await request(app)
      .patch(`/api/complaints/${complaintId}/classification`)
      .set('Authorization', `Bearer ${studentToken}`)
      .send({ category: 'Plumbing' });

    expect(res.status).toBe(403);
  });

  it('lets a student list only their own complaints', async () => {
    const res = await request(app)
      .get('/api/complaints')
      .set('Authorization', `Bearer ${studentToken}`);

    expect(res.status).toBe(200);
    expect(res.body.complaints.every((c) => c.user_id)).toBe(true);
  });

  it('lets an admin list all complaints', async () => {
    const res = await request(app)
      .get('/api/complaints')
      .set('Authorization', `Bearer ${adminToken}`);

    expect(res.status).toBe(200);
    expect(res.body.count).toBeGreaterThanOrEqual(1);
  });

  it('blocks a student from updating status', async () => {
    const res = await request(app)
      .patch(`/api/complaints/${complaintId}/status`)
      .set('Authorization', `Bearer ${studentToken}`)
      .send({ status: 'Resolved' });

    expect(res.status).toBe(403);
  });

  it('lets an admin update complaint status', async () => {
    const res = await request(app)
      .patch(`/api/complaints/${complaintId}/status`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ status: 'In Progress' });

    expect(res.status).toBe(200);
    expect(res.body.complaint.status).toBe('In Progress');
  });

  it('returns 404 for a non-existent complaint', async () => {
    const res = await request(app)
      .get('/api/complaints/999999')
      .set('Authorization', `Bearer ${studentToken}`);

    expect(res.status).toBe(404);
  });

  it('blocks another student from deleting someone else\'s complaint', async () => {
    const other = await request(app).post('/api/auth/register').send({
      name: 'Other Student',
      email: 'other.student@test.com',
      password: 'password123',
    });

    const res = await request(app)
      .delete(`/api/complaints/${complaintId}`)
      .set('Authorization', `Bearer ${other.body.token}`);

    expect(res.status).toBe(403);
  });

  it('lets the owner delete their complaint', async () => {
    const res = await request(app)
      .delete(`/api/complaints/${complaintId}`)
      .set('Authorization', `Bearer ${studentToken}`);

    expect(res.status).toBe(200);
  });
});
