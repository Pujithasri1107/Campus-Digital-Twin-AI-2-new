const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { AppError } = require('../middleware/errorHandler');

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

async function register(req, res, next) {
  try {
    const { name, email, password, role } = req.body;
    const finalRole = role === 'admin' ? 'admin' : 'student';

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      return next(new AppError('An account with this email already exists', 409));
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = db
      .prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)')
      .run(name, email, passwordHash, finalRole);

    const user = { id: result.lastInsertRowid, email, role: finalRole };
    const token = signToken(user);

    res.status(201).json({
      success: true,
      token,
      user: { id: user.id, name, email, role: finalRole },
    });
  } catch (err) {
    next(err);
  }
}

async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) {
      return next(new AppError('Invalid email or password', 401));
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return next(new AppError('Invalid email or password', 401));
    }

    const token = signToken(user);

    res.json({
      success: true,
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (err) {
    next(err);
  }
}

async function me(req, res, next) {
  try {
    const user = db
      .prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?')
      .get(req.user.id);

    if (!user) return next(new AppError('User not found', 404));

    res.json({ success: true, user });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login, me };
