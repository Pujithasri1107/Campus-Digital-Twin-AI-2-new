const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.DB_PATH || './data/campus.db';
const resolvedPath = path.resolve(DB_PATH);

// Ensure the directory for the db file exists
const dir = path.dirname(resolvedPath);
if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true });
}

const rawDb = new DatabaseSync(resolvedPath);
rawDb.exec('PRAGMA journal_mode = WAL');
rawDb.exec('PRAGMA foreign_keys = ON');

function initSchema() {
  // --- original tables (unchanged, so nothing that already works breaks) ---
  rawDb.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('student', 'admin')) DEFAULT 'student',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      building TEXT,
      room TEXT,
      category TEXT NOT NULL DEFAULT 'Uncategorized',
      priority TEXT NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High')),
      status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Resolved', 'Rejected')),
      photo_path TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_complaints_user_id ON complaints(user_id);
    CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
    CREATE INDEX IF NOT EXISTS idx_complaints_category ON complaints(category);
    CREATE INDEX IF NOT EXISTS idx_complaints_building ON complaints(building);
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
  `);

  // --- NEW: digital twin locations ---
  rawDb.exec(`
    CREATE TABLE IF NOT EXISTS locations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      parent_id INTEGER REFERENCES locations(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK (type IN ('building','floor','room','zone','outdoor_area')),
      building_name TEXT,
      floor_number INTEGER,
      map_x REAL,
      map_y REAL,
      latitude REAL,
      longitude REAL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_locations_parent ON locations(parent_id);
    CREATE INDEX IF NOT EXISTS idx_locations_building ON locations(building_name);
  `);

  // Link complaints -> locations. ALTER TABLE ADD COLUMN throws if the
  // column already exists, so this is guarded to stay idempotent across
  // server restarts.
  try {
    rawDb.exec(`ALTER TABLE complaints ADD COLUMN location_id INTEGER REFERENCES locations(id);`);
  } catch (err) {
    if (!/duplicate column name/i.test(err.message)) throw err;
  }

  // --- NEW: full AI analysis history per complaint ---
  rawDb.exec(`
    CREATE TABLE IF NOT EXISTS ai_analysis (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_id INTEGER NOT NULL UNIQUE REFERENCES complaints(id) ON DELETE CASCADE,
      predicted_category TEXT NOT NULL CHECK (predicted_category IN ('Electrical','Plumbing','Furniture','Civil','Other')),
      severity TEXT NOT NULL CHECK (severity IN ('Minor','Moderate','Severe')),
      confidence_score REAL,
      is_recurring_issue INTEGER NOT NULL DEFAULT 0 CHECK (is_recurring_issue IN (0,1)),
      recurring_count INTEGER DEFAULT 0,
      suggested_priority TEXT NOT NULL CHECK (suggested_priority IN ('Low','Medium','High')),
      ai_notes TEXT,
      analyzed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_ai_analysis_complaint ON ai_analysis(complaint_id);
  `);

  // --- NEW: maintenance staff + dispatch ---
  rawDb.exec(`
    CREATE TABLE IF NOT EXISTS staff_profiles (
      id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      specialty TEXT NOT NULL CHECK (specialty IN ('Electrical','Plumbing','Furniture','Civil','Other')),
      is_available INTEGER NOT NULL DEFAULT 1 CHECK (is_available IN (0,1))
    );

    CREATE TABLE IF NOT EXISTS maintenance_assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
      assigned_by INTEGER NOT NULL REFERENCES users(id),
      assigned_to INTEGER NOT NULL REFERENCES staff_profiles(id),
      assigned_at TEXT NOT NULL DEFAULT (datetime('now')),
      completed_at TEXT,
      remarks TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_assignments_complaint ON maintenance_assignments(complaint_id);
    CREATE INDEX IF NOT EXISTS idx_assignments_staff ON maintenance_assignments(assigned_to);
  `);

  // --- NEW: status change audit trail ---
  rawDb.exec(`
    CREATE TABLE IF NOT EXISTS complaint_status_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
      old_status TEXT,
      new_status TEXT NOT NULL,
      changed_by INTEGER REFERENCES users(id),
      changed_at TEXT NOT NULL DEFAULT (datetime('now')),
      note TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_status_history_complaint ON complaint_status_history(complaint_id);
  `);
}

initSchema();

/**
 * Thin wrapper so the rest of the codebase can keep using the familiar
 * db.prepare(sql).run/get/all(...) pattern regardless of which underlying
 * SQLite driver is used.
 */
const db = {
  prepare(sql) {
    return rawDb.prepare(sql);
  },
  exec(sql) {
    return rawDb.exec(sql);
  },
  raw: rawDb,
};

module.exports = db;
