const fs = require('fs');

// URL of Member 4's Java Spring Boot AI microservice.
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://localhost:8081';
const AI_TIMEOUT_MS = Number(process.env.AI_TIMEOUT_MS || 8000);

function withTimeout(promise, ms) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return { promise: promise(controller.signal), controller, clear: () => clearTimeout(timer) };
}

/**
 * Calls the AI microservice's one-call pipeline: POST /api/ai/analyze-complaint
 * (multipart/form-data: description, building, room, file?).
 *
 * Never throws — on any failure (service down, timeout, bad response) it
 * returns a safe fallback object instead, so a complaint submission never
 * fails just because the AI service is unreachable. This mirrors the
 * fallback pattern already used inside the AI service itself.
 */
async function analyzeComplaint({ description, building, room, photoPath }) {
  const fallback = {
    ok: false,
    category: 'Uncategorized',
    priority: 'Medium',
    severity: 'Moderate',
    confidence: null,
    isRecurring: false,
    recurringCount: 0,
    aiNotes: 'AI service unavailable — default values applied.',
  };

  try {
    const form = new FormData();
    form.append('description', description || '');
    form.append('building', building || 'Unknown');
    if (room) form.append('room', room);

    if (photoPath && fs.existsSync(photoPath)) {
      const buffer = fs.readFileSync(photoPath);
      const blob = new Blob([buffer]);
      form.append('file', blob, 'photo.jpg');
    }

    const { promise, clear } = withTimeout(
      (signal) =>
        fetch(`${AI_SERVICE_URL}/api/ai/analyze-complaint`, {
          method: 'POST',
          body: form,
          signal,
        }),
      AI_TIMEOUT_MS
    );

    const res = await promise;
    clear();

    if (!res.ok) {
      return { ...fallback, aiNotes: `AI service returned HTTP ${res.status}` };
    }

    const data = await res.json();

    return {
      ok: true,
      category: data.category || fallback.category,
      priority: data.priority || fallback.priority,
      severity: severityFromPriority(data.priority),
      confidence: data.imageAnalysis?.confidence ?? data.textAnalysis?.confidence ?? null,
      isRecurring: Boolean(data.recurringCheck?.recurring),
      recurringCount: data.recurringCheck?.occurrences || 0,
      aiNotes: data.textAnalysis?.reasoning || data.recurringCheck?.suggestion || null,
      raw: data,
    };
  } catch (err) {
    return { ...fallback, aiNotes: `AI service error: ${err.message}` };
  }
}

function severityFromPriority(priority) {
  if (priority === 'High') return 'Severe';
  if (priority === 'Low') return 'Minor';
  return 'Moderate';
}

/** Simple health check used by the /api/ai/health passthrough route. */
async function checkHealth() {
  try {
    const { promise, clear } = withTimeout(
      (signal) => fetch(`${AI_SERVICE_URL}/api/ai/health`, { signal }),
      3000
    );
    const res = await promise;
    clear();
    return res.ok;
  } catch {
    return false;
  }
}

module.exports = { analyzeComplaint, checkHealth, AI_SERVICE_URL };
