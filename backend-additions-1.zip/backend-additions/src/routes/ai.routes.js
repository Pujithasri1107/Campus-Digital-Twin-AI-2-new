const express = require('express');
const { param } = require('express-validator');
const validate = require('../middleware/validate');
const { authenticate, requireRole } = require('../middleware/auth');
const { analyzeComplaint, getAnalysis, preventiveSuggestions, health } = require('../controllers/ai.controller');

const router = express.Router();

router.get('/health', health);

router.use(authenticate);

router.post(
  '/analyze/:complaintId',
  requireRole('admin'),
  [param('complaintId').isInt().withMessage('Invalid complaint id')],
  validate,
  analyzeComplaint
);

router.get(
  '/analysis/:complaintId',
  [param('complaintId').isInt().withMessage('Invalid complaint id')],
  validate,
  getAnalysis
);

router.get('/preventive', requireRole('admin'), preventiveSuggestions);

module.exports = router;
