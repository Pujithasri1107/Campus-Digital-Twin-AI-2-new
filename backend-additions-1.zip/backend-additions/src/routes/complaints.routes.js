const express = require('express');
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const { authenticate, requireRole } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const {
  createComplaint,
  listComplaints,
  getComplaint,
  updateStatus,
  updateClassification,
  deleteComplaint,
} = require('../controllers/complaints.controller');
const { assignStaff } = require('../controllers/staff.controller');

const router = express.Router();

router.use(authenticate);

router.post(
  '/',
  upload.single('photo'),
  [
    body('title').trim().notEmpty().withMessage('Title is required'),
    body('description').trim().notEmpty().withMessage('Description is required'),
    body('category').optional().trim(),
    body('priority').optional().isIn(['Low', 'Medium', 'High']).withMessage('Invalid priority value'),
  ],
  validate,
  createComplaint
);

router.get('/', listComplaints);

router.get('/:id', [param('id').isInt().withMessage('Invalid complaint id')], validate, getComplaint);

router.patch(
  '/:id/status',
  requireRole('admin'),
  [
    param('id').isInt().withMessage('Invalid complaint id'),
    body('status')
      .isIn(['Open', 'In Progress', 'Resolved', 'Rejected'])
      .withMessage('Invalid status value'),
  ],
  validate,
  updateStatus
);

router.patch(
  '/:id/classification',
  requireRole('admin'),
  [
    param('id').isInt().withMessage('Invalid complaint id'),
    body('category').optional().trim(),
    body('priority').optional().isIn(['Low', 'Medium', 'High']).withMessage('Invalid priority value'),
  ],
  validate,
  updateClassification
);

router.post(
  '/:id/assign',
  requireRole('admin'),
  [
    param('id').isInt().withMessage('Invalid complaint id'),
    body('staffId').isInt().withMessage('staffId is required'),
  ],
  validate,
  assignStaff
);

router.delete('/:id', [param('id').isInt().withMessage('Invalid complaint id')], validate, deleteComplaint);

module.exports = router;
