const express = require('express');
const { authenticate, requireRole } = require('../middleware/auth');
const { getStats, getDashboardFeed } = require('../controllers/admin.controller');

const router = express.Router();

router.use(authenticate, requireRole('admin'));

router.get('/stats', getStats);
router.get('/dashboard-feed', getDashboardFeed);

module.exports = router;
