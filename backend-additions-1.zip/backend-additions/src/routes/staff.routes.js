const express = require('express');
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { authenticate, requireRole } = require('../middleware/auth');
const { listStaff, createStaffProfile, completeAssignment } = require('../controllers/staff.controller');

const router = express.Router();

router.use(authenticate, requireRole('admin'));

router.get('/', listStaff);

router.post(
  '/',
  [
    body('userId').isInt().withMessage('userId is required'),
    body('specialty')
      .isIn(['Electrical', 'Plumbing', 'Furniture', 'Civil', 'Other'])
      .withMessage('Invalid specialty'),
  ],
  validate,
  createStaffProfile
);

router.patch('/assignments/:id/complete', completeAssignment);

module.exports = router;
