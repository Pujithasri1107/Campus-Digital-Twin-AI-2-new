const db = require('../config/db');

// GET /api/admin/stats
async function getStats(req, res, next) {
  try {
    const total = db.prepare('SELECT COUNT(*) AS count FROM complaints').get().count;

    const byStatus = db
      .prepare('SELECT status, COUNT(*) AS count FROM complaints GROUP BY status')
      .all();

    const byCategory = db
      .prepare('SELECT category, COUNT(*) AS count FROM complaints GROUP BY category ORDER BY count DESC')
      .all();

    const byPriority = db
      .prepare('SELECT priority, COUNT(*) AS count FROM complaints GROUP BY priority')
      .all();

    const byBuilding = db
      .prepare(
        `SELECT building, COUNT(*) AS count FROM complaints
         WHERE building IS NOT NULL
         GROUP BY building ORDER BY count DESC LIMIT 10`
      )
      .all();

    const highPriorityOpen = db
      .prepare(`SELECT COUNT(*) AS count FROM complaints WHERE priority = 'High' AND status != 'Resolved'`)
      .get().count;

    res.json({
      success: true,
      stats: {
        total,
        highPriorityOpen,
        byStatus,
        byCategory,
        byPriority,
        mostAffectedBuildings: byBuilding,
      },
    });
  } catch (err) {
    next(err);
  }
}

// GET /api/admin/dashboard-feed  (Step 8 — full join for the live dashboard table)
async function getDashboardFeed(req, res, next) {
  try {
    const rows = db
      .prepare(
        `SELECT c.id, c.title, c.description, c.building, c.room, c.photo_path,
                c.status, c.priority, c.category, c.created_at, c.updated_at,
                a.predicted_category, a.severity, a.confidence_score,
                a.is_recurring_issue, a.recurring_count, a.ai_notes,
                m.id AS assignment_id, m.assigned_to, m.completed_at AS assignment_completed_at,
                u.name AS assigned_staff_name
         FROM complaints c
         LEFT JOIN ai_analysis a ON a.complaint_id = c.id
         LEFT JOIN maintenance_assignments m
                ON m.complaint_id = c.id
               AND m.id = (SELECT MAX(id) FROM maintenance_assignments WHERE complaint_id = c.id)
         LEFT JOIN users u ON u.id = m.assigned_to
         ORDER BY
           CASE c.priority WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END,
           c.created_at DESC`
      )
      .all();

    res.json({ success: true, count: rows.length, complaints: rows });
  } catch (err) {
    next(err);
  }
}

module.exports = { getStats, getDashboardFeed };
