const db = require('../config/db');
const { AppError } = require('../middleware/errorHandler');

// GET /api/staff  (admin) — list maintenance staff, optionally filter by specialty/availability
async function listStaff(req, res, next) {
  try {
    const { specialty, available } = req.query;
    const conditions = [];
    const params = [];

    if (specialty) {
      conditions.push('sp.specialty = ?');
      params.push(specialty);
    }
    if (available !== undefined) {
      conditions.push('sp.is_available = ?');
      params.push(available === 'true' ? 1 : 0);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const staff = db
      .prepare(
        `SELECT u.id, u.name, u.email, sp.specialty, sp.is_available
         FROM staff_profiles sp
         JOIN users u ON u.id = sp.id
         ${where}
         ORDER BY sp.is_available DESC, u.name ASC`
      )
      .all(...params);

    res.json({ success: true, staff });
  } catch (err) {
    next(err);
  }
}

// POST /api/staff  (admin) — promote an existing user to a staff profile
async function createStaffProfile(req, res, next) {
  try {
    const { userId, specialty } = req.body;
    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(userId);
    if (!user) return next(new AppError('User not found', 404));

    db.prepare(
      `INSERT INTO staff_profiles (id, specialty, is_available)
       VALUES (?, ?, 1)
       ON CONFLICT(id) DO UPDATE SET specialty = excluded.specialty`
    ).run(userId, specialty);

    const profile = db
      .prepare(
        `SELECT u.id, u.name, u.email, sp.specialty, sp.is_available
         FROM staff_profiles sp JOIN users u ON u.id = sp.id WHERE sp.id = ?`
      )
      .get(userId);

    res.status(201).json({ success: true, staff: profile });
  } catch (err) {
    next(err);
  }
}

// POST /api/complaints/:id/assign  (admin) — dispatch a staff member to a complaint
async function assignStaff(req, res, next) {
  try {
    const complaintId = req.params.id;
    const { staffId, remarks } = req.body;

    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(complaintId);
    if (!complaint) return next(new AppError('Complaint not found', 404));

    const staff = db.prepare('SELECT * FROM staff_profiles WHERE id = ?').get(staffId);
    if (!staff) return next(new AppError('Staff profile not found', 404));

    const result = db
      .prepare(
        `INSERT INTO maintenance_assignments (complaint_id, assigned_by, assigned_to, remarks)
         VALUES (?, ?, ?, ?)`
      )
      .run(complaintId, req.user.id, staffId, remarks || null);

    db.prepare(`UPDATE staff_profiles SET is_available = 0 WHERE id = ?`).run(staffId);

    if (complaint.status === 'Open') {
      db.prepare(
        `UPDATE complaints SET status = 'In Progress', updated_at = datetime('now') WHERE id = ?`
      ).run(complaintId);
      db.prepare(
        `INSERT INTO complaint_status_history (complaint_id, old_status, new_status, changed_by, note)
         VALUES (?, 'Open', 'In Progress', ?, 'Auto-updated on staff assignment')`
      ).run(complaintId, req.user.id);
    }

    const assignment = db
      .prepare(
        `SELECT m.*, u.name AS assigned_staff_name
         FROM maintenance_assignments m JOIN users u ON u.id = m.assigned_to
         WHERE m.id = ?`
      )
      .get(result.lastInsertRowid);

    res.status(201).json({ success: true, assignment });
  } catch (err) {
    next(err);
  }
}

// PATCH /api/assignments/:id/complete  (admin) — mark a dispatch as completed, frees the staff member
async function completeAssignment(req, res, next) {
  try {
    const assignment = db.prepare('SELECT * FROM maintenance_assignments WHERE id = ?').get(req.params.id);
    if (!assignment) return next(new AppError('Assignment not found', 404));

    db.prepare(`UPDATE maintenance_assignments SET completed_at = datetime('now') WHERE id = ?`).run(
      req.params.id
    );
    db.prepare(`UPDATE staff_profiles SET is_available = 1 WHERE id = ?`).run(assignment.assigned_to);

    res.json({ success: true, message: 'Assignment marked complete, staff member is available again' });
  } catch (err) {
    next(err);
  }
}

module.exports = { listStaff, createStaffProfile, assignStaff, completeAssignment };
