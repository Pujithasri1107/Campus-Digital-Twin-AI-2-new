const db = require('../config/db');
const { AppError } = require('../middleware/errorHandler');
const aiClient = require('../utils/aiClient');

const VALID_CATEGORIES = ['Electrical', 'Plumbing', 'Furniture', 'Civil', 'Other'];

function normalizeCategory(category) {
  return VALID_CATEGORIES.includes(category) ? category : 'Other';
}

/**
 * POST /api/ai/analyze/:complaintId  (admin, or called internally right
 * after complaint creation)
 *
 * Calls the AI microservice, stores the full result in `ai_analysis`
 * (Step 5-7), and mirrors category/priority back onto the complaint via
 * the same fields the existing PATCH /classification endpoint updates.
 */
async function analyzeComplaint(req, res, next) {
  try {
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.complaintId);
    if (!complaint) return next(new AppError('Complaint not found', 404));

    const result = await aiClient.analyzeComplaint({
      description: complaint.description,
      building: complaint.building,
      room: complaint.room,
      photoPath: complaint.photo_path ? `.${complaint.photo_path}` : null,
    });

    const category = normalizeCategory(result.category);

    db.prepare(
      `INSERT INTO ai_analysis
        (complaint_id, predicted_category, severity, confidence_score, is_recurring_issue, recurring_count, suggested_priority, ai_notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(complaint_id) DO UPDATE SET
        predicted_category = excluded.predicted_category,
        severity = excluded.severity,
        confidence_score = excluded.confidence_score,
        is_recurring_issue = excluded.is_recurring_issue,
        recurring_count = excluded.recurring_count,
        suggested_priority = excluded.suggested_priority,
        ai_notes = excluded.ai_notes,
        analyzed_at = datetime('now')`
    ).run(
      complaint.id,
      category,
      result.severity,
      result.confidence,
      result.isRecurring ? 1 : 0,
      result.recurringCount,
      result.priority,
      result.aiNotes
    );

    db.prepare(
      `UPDATE complaints SET category = ?, priority = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(category, result.priority, complaint.id);

    const analysis = db.prepare('SELECT * FROM ai_analysis WHERE complaint_id = ?').get(complaint.id);

    res.json({ success: true, aiServiceReachable: result.ok, analysis });
  } catch (err) {
    next(err);
  }
}

// GET /api/ai/analysis/:complaintId
async function getAnalysis(req, res, next) {
  try {
    const analysis = db
      .prepare('SELECT * FROM ai_analysis WHERE complaint_id = ?')
      .get(req.params.complaintId);

    if (!analysis) return next(new AppError('No AI analysis for this complaint yet', 404));

    res.json({ success: true, analysis });
  } catch (err) {
    next(err);
  }
}

// GET /api/ai/preventive  (Step 11 — buildings/categories with 3+ issues in 90 days)
async function preventiveSuggestions(req, res, next) {
  try {
    const rows = db
      .prepare(
        `SELECT c.building AS building_name, a.predicted_category, COUNT(*) AS issue_count
         FROM complaints c
         JOIN ai_analysis a ON a.complaint_id = c.id
         WHERE c.created_at > datetime('now', '-90 days')
           AND c.building IS NOT NULL
         GROUP BY c.building, a.predicted_category
         HAVING COUNT(*) >= 3
         ORDER BY issue_count DESC`
      )
      .all();

    res.json({ success: true, suggestions: rows });
  } catch (err) {
    next(err);
  }
}

// GET /api/ai/health  (passthrough health check for the dashboard status pill)
async function health(req, res) {
  const reachable = await aiClient.checkHealth();
  res.json({ success: true, aiServiceUrl: aiClient.AI_SERVICE_URL, reachable });
}

module.exports = { analyzeComplaint, getAnalysis, preventiveSuggestions, health };
