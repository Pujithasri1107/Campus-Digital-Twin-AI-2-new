const db = require('../config/db');
const { AppError } = require('../middleware/errorHandler');
const aiClient = require('../utils/aiClient');

const VALID_CATEGORIES = ['Electrical', 'Plumbing', 'Furniture', 'Civil', 'Other'];

/**
 * Fires the AI pipeline in the background after a complaint is created, so
 * the student's submission response isn't slowed down waiting on it. Any
 * failure here is swallowed — aiClient.analyzeComplaint() already returns a
 * safe fallback rather than throwing, so this is just a defensive wrapper.
 */
function triggerBackgroundAnalysis(complaint) {
  setImmediate(async () => {
    try {
      const result = await aiClient.analyzeComplaint({
        description: complaint.description,
        building: complaint.building,
        room: complaint.room,
        photoPath: complaint.photo_path ? `.${complaint.photo_path}` : null,
      });

      const category = VALID_CATEGORIES.includes(result.category) ? result.category : 'Other';

      db.prepare(
        `INSERT INTO ai_analysis
          (complaint_id, predicted_category, severity, confidence_score, is_recurring_issue, recurring_count, suggested_priority, ai_notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(complaint_id) DO UPDATE SET
          predicted_category = excluded.predicted_category,
          severity = excluded.severity,
          confidence_score = excluded.confidence_score,
          is_recurring_issue = excluded.is_recurring_issue,
          recurring_count = excluded.recurring_count,
          suggested_priority = excluded.suggested_priority,
          ai_notes = excluded.ai_notes,
          analyzed_at = datetime('now')`
      ).run(
        complaint.id,
        category,
        result.severity,
        result.confidence,
        result.isRecurring ? 1 : 0,
        result.recurringCount,
        result.priority,
        result.aiNotes
      );

      db.prepare(
        `UPDATE complaints SET category = ?, priority = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(category, result.priority, complaint.id);
    } catch (err) {
      console.error('[background AI analysis failed]', err.message);
    }
  });
}

// POST /api/complaints  (student)
// Note: category/priority are plain fields here, not AI-classified. Member 4's
// AI module owns classification and can update these fields later via
// PATCH /api/complaints/:id/classification (see updateClassification below).
async function createComplaint(req, res, next) {
  try {
    const { title, description, building, room } = req.body;
    const category = req.body.category || 'Uncategorized';
    const priority = ['Low', 'Medium', 'High'].includes(req.body.priority) ? req.body.priority : 'Medium';
    const photoPath = req.file ? `/uploads/${req.file.filename}` : null;

    const result = db
      .prepare(
        `INSERT INTO complaints (user_id, title, description, building, room, category, priority, photo_path)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(req.user.id, title, description, building || null, room || null, category, priority, photoPath);

    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(result.lastInsertRowid);

    triggerBackgroundAnalysis(complaint);

    res.status(201).json({ success: true, complaint });
  } catch (err) {
    next(err);
  }
}

// GET /api/complaints  (student: own complaints, admin: all, with filters)
async function listComplaints(req, res, next) {
  try {
    const { status, category, building } = req.query;
    const isAdmin = req.user.role === 'admin';

    const conditions = [];
    const params = [];

    if (!isAdmin) {
      conditions.push('user_id = ?');
      params.push(req.user.id);
    }
    if (status) {
      conditions.push('status = ?');
      params.push(status);
    }
    if (category) {
      conditions.push('category = ?');
      params.push(category);
    }
    if (building) {
      conditions.push('building = ?');
      params.push(building);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const complaints = db
      .prepare(`SELECT * FROM complaints ${where} ORDER BY created_at DESC`)
      .all(...params);

    res.json({ success: true, count: complaints.length, complaints });
  } catch (err) {
    next(err);
  }
}

// GET /api/complaints/:id
async function getComplaint(req, res, next) {
  try {
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);

    if (!complaint) return next(new AppError('Complaint not found', 404));

    const isOwner = complaint.user_id === req.user.id;
    if (req.user.role !== 'admin' && !isOwner) {
      return next(new AppError('You do not have permission to view this complaint', 403));
    }

    res.json({ success: true, complaint });
  } catch (err) {
    next(err);
  }
}

// PATCH /api/complaints/:id/status  (admin only)
async function updateStatus(req, res, next) {
  try {
    const { status } = req.body;
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);

    if (!complaint) return next(new AppError('Complaint not found', 404));

    db.prepare(`UPDATE complaints SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(
      status,
      req.params.id
    );

    db.prepare(
      `INSERT INTO complaint_status_history (complaint_id, old_status, new_status, changed_by)
       VALUES (?, ?, ?, ?)`
    ).run(req.params.id, complaint.status, status, req.user.id);

    const updated = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);
    res.json({ success: true, complaint: updated });
  } catch (err) {
    next(err);
  }
}

// PATCH /api/complaints/:id/classification  (admin only for now)
// Hook for Member 4's AI module to set category/priority once it classifies
// a complaint. Kept separate from updateStatus so the two concerns don't mix.
async function updateClassification(req, res, next) {
  try {
    const { category, priority } = req.body;
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);

    if (!complaint) return next(new AppError('Complaint not found', 404));

    db.prepare(
      `UPDATE complaints SET category = COALESCE(?, category), priority = COALESCE(?, priority), updated_at = datetime('now') WHERE id = ?`
    ).run(category || null, priority || null, req.params.id);

    const updated = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);
    res.json({ success: true, complaint: updated });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/complaints/:id  (owner or admin)
async function deleteComplaint(req, res, next) {
  try {
    const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(req.params.id);
    if (!complaint) return next(new AppError('Complaint not found', 404));

    const isOwner = complaint.user_id === req.user.id;
    if (req.user.role !== 'admin' && !isOwner) {
      return next(new AppError('You do not have permission to delete this complaint', 403));
    }

    db.prepare('DELETE FROM complaints WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Complaint deleted' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createComplaint,
  listComplaints,
  getComplaint,
  updateStatus,
  updateClassification,
  deleteComplaint,
};
