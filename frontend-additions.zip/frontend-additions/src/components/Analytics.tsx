import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart, PieChart, TrendingUp, AlertOctagon, ClipboardList, Loader2 } from 'lucide-react';
import { getDashboardFeed, getAdminStats } from '../lib/api';
import type { Complaint, AdminStats } from '../lib/api';

const statusColors: Record<string, string> = {
  Open: '#F59E0B',
  'In Progress': '#2563EB',
  Resolved: '#10B981',
  Rejected: '#6B7280',
};

const priorityColors: Record<string, string> = {
  High: '#EF4444',
  Medium: '#F59E0B',
  Low: '#38BDF8',
};

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function Analytics() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [s, feed] = await Promise.all([getAdminStats(), getDashboardFeed()]);
        setStats(s);
        setComplaints(feed);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load analytics. Are you logged in as admin?');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const total = stats?.total ?? 0;
  const resolved = stats?.byStatus.find((s) => s.status === 'Resolved')?.count ?? 0;
  const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;
  const healthGrade = resolutionRate >= 80 ? 'A+' : resolutionRate >= 60 ? 'B' : resolutionRate >= 40 ? 'C' : total === 0 ? '—' : 'D';
  const healthLabel = resolutionRate >= 80 ? 'Excellent' : resolutionRate >= 60 ? 'Good' : resolutionRate >= 40 ? 'Needs attention' : total === 0 ? 'No data yet' : 'At risk';

  // Real last-7-days submission counts, grouped by weekday, from live complaints
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const weekCounts = [0, 0, 0, 0, 0, 0, 0];
  complaints.forEach((c) => {
    const created = new Date(c.created_at.replace(' ', 'T'));
    if (created >= sevenDaysAgo) {
      weekCounts[created.getDay()] += 1;
    }
  });
  const maxWeekCount = Math.max(1, ...weekCounts);

  const byStatus = stats?.byStatus ?? [];
  const statusTotal = byStatus.reduce((acc, s) => acc + s.count, 0) || 1;

  return (
    <section id="dashboard" className="relative py-16 sm:py-20 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-1/4 right-1/3 w-48 sm:w-64 lg:w-80 h-48 sm:h-64 lg:h-80 bg-secondary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10 sm:mb-12 lg:mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block px-3 py-1 sm:px-4 sm:py-1.5 rounded-full glass-card text-secondary text-xs sm:text-sm font-medium mb-3 sm:mb-4"
          >
            Data Insights
          </motion.span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-white mb-3 sm:mb-4">
            Analytics <span className="gradient-text">& Reports</span>
          </h2>
          <p className="text-sm sm:text-base text-gray-400 max-w-xl lg:max-w-2xl mx-auto px-4">
            Live figures computed from real complaint data.
          </p>
        </motion.div>

        {error && (
          <div className="mb-6 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300 text-center">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-24 text-gray-400 gap-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading analytics...
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
              {[
                { icon: ClipboardList, label: 'Total Complaints', value: String(total) },
                { icon: TrendingUp, label: 'Resolution Rate', value: `${resolutionRate}%` },
                { icon: AlertOctagon, label: 'High Priority Open', value: String(stats?.highPriorityOpen ?? 0) },
              ].map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="glass-card rounded-lg sm:rounded-xl p-3 sm:p-4 lg:p-5"
                >
                  <div className="flex items-center gap-2 sm:gap-3 mb-2 sm:mb-3">
                    <div className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                      <item.icon className="w-3 h-3 sm:w-3.5 sm:h-3.5 lg:w-4 lg:h-4 text-secondary" />
                    </div>
                    <span className="text-[10px] sm:text-xs lg:text-sm text-gray-400 hidden sm:inline">{item.label}</span>
                  </div>
                  <div className="flex items-baseline gap-1.5 sm:gap-2">
                    <span className="text-lg sm:text-xl lg:text-2xl font-bold text-white">{item.value}</span>
                  </div>
                  <span className="text-[10px] sm:text-xs text-gray-400 sm:hidden mt-1">{item.label}</span>
                </motion.div>
              ))}

              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="glass-card rounded-lg sm:rounded-xl p-3 sm:p-4 lg:p-5 bg-gradient-to-br from-green-500/20 to-green-500/5 col-span-2 lg:col-span-1"
              >
                <div className="text-center">
                  <p className="text-[10px] sm:text-xs lg:text-sm text-gray-400 mb-1 sm:mb-2">Campus Health</p>
                  <p className="text-2xl sm:text-3xl lg:text-4xl font-bold text-green-400">{healthGrade}</p>
                  <p className="text-[10px] sm:text-xs text-green-300 mt-0.5 sm:mt-1">{healthLabel}</p>
                </div>
              </motion.div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              {/* Weekly submissions bar chart — real data */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-5 lg:p-6"
              >
                <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <BarChart className="w-4 h-4 sm:w-4.5 sm:h-4.5 lg:w-5 lg:h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-sm sm:text-base">Complaints Submitted</h4>
                    <p className="text-[10px] sm:text-xs text-gray-400">Last 7 days, by weekday</p>
                  </div>
                </div>

                <div className="flex items-end justify-between h-32 sm:h-36 lg:h-40 px-1 sm:px-2 gap-2">
                  {weekCounts.map((value, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center justify-end h-full">
                      <span className="text-[10px] text-gray-400 mb-1">{value || ''}</span>
                      <motion.div
                        initial={{ height: 0 }}
                        whileInView={{ height: `${(value / maxWeekCount) * 100}%` }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.05, duration: 0.5 }}
                        className="w-full max-w-8 rounded-t-md min-h-[4px]"
                        style={{ background: 'linear-gradient(180deg, #2563EB, #38BDF8)', opacity: 0.85 }}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-3 sm:mt-4 text-[10px] sm:text-xs text-gray-500 px-1 sm:px-2">
                  {WEEKDAYS.map((day) => (
                    <span key={day}>{day}</span>
                  ))}
                </div>
              </motion.div>

              {/* Status distribution pie — real data */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-5 lg:p-6"
              >
                <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                    <PieChart className="w-4 h-4 sm:w-4.5 sm:h-4.5 lg:w-5 lg:h-5 text-accent" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-sm sm:text-base">Status Distribution</h4>
                    <p className="text-[10px] sm:text-xs text-gray-400">All complaints</p>
                  </div>
                </div>

                {byStatus.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-8">No data yet.</p>
                ) : (
                  <>
                    <div className="flex items-center justify-center h-28 sm:h-32 lg:h-36">
                      <div className="relative w-24 h-24 sm:w-28 sm:h-28 lg:w-32 lg:h-32">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          {byStatus.map((item, index) => {
                            const pct = (item.count / statusTotal) * 100;
                            const offset = byStatus.slice(0, index).reduce((acc, cur) => acc + (cur.count / statusTotal) * 100, 0);
                            const circumference = 2 * Math.PI * 40;
                            const strokeDashoffset = circumference - (pct / 100) * circumference;
                            const rotation = (offset / 100) * 360;
                            const color = statusColors[item.status] ?? '#6B7280';

                            return (
                              <circle
                                key={item.status}
                                cx="50"
                                cy="50"
                                r="40"
                                fill="none"
                                stroke={color}
                                strokeWidth="20"
                                strokeDasharray={circumference}
                                strokeDashoffset={strokeDashoffset}
                                transform={`rotate(${rotation} 50 50)`}
                                style={{ transformOrigin: 'center' }}
                              />
                            );
                          })}
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="text-center">
                            <p className="text-base sm:text-lg lg:text-xl font-bold text-white">{total}</p>
                            <p className="text-[10px] sm:text-xs text-gray-400">Total</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap justify-center gap-3 sm:gap-4 mt-3 sm:mt-4">
                      {byStatus.map((item) => (
                        <div key={item.status} className="flex items-center gap-1 sm:gap-2">
                          <div
                            className="w-2 h-2 sm:w-2.5 sm:h-2.5 lg:w-3 lg:h-3 rounded-full"
                            style={{ backgroundColor: statusColors[item.status] ?? '#6B7280' }}
                          />
                          <span className="text-[10px] sm:text-xs text-gray-400">{item.status} ({item.count})</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </motion.div>
            </div>

            {/* Priority mini bar */}
            {stats && stats.byPriority.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-5 lg:p-6 mt-4 sm:mt-6"
              >
                <h4 className="font-semibold text-white text-sm sm:text-base mb-4">Priority Breakdown</h4>
                <div className="space-y-3">
                  {stats.byPriority.map((p) => {
                    const pct = total > 0 ? Math.round((p.count / total) * 100) : 0;
                    return (
                      <div key={p.priority}>
                        <div className="flex justify-between text-xs sm:text-sm mb-1.5">
                          <span className="text-gray-300">{p.priority}</span>
                          <span className="text-white font-medium">{p.count}</span>
                        </div>
                        <div className="h-2 sm:h-2.5 rounded-full bg-white/5 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${pct}%`, background: priorityColors[p.priority] ?? '#6B7280' }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </>
        )}
      </div>
    </section>
  );
}
