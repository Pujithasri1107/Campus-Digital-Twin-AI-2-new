import { useEffect, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  ClipboardList,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Zap,
  HardHat,
  RefreshCw,
  UserPlus,
  Sparkles,
  Loader2,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import {
  getDashboardFeed,
  getAdminStats,
  updateComplaintStatus,
  triggerAiAnalysis,
  getStaff,
  assignStaffToComplaint,
  getPreventiveSuggestions,
} from '../lib/api';
import type { Complaint, AdminStats, StaffMember } from '../lib/api';

interface SummaryCard {
  icon: LucideIcon;
  value: string;
  label: string;
  color: string;
  gradient: string;
  border: string;
}

const STATUS_OPTIONS: Complaint['status'][] = ['Open', 'In Progress', 'Resolved', 'Rejected'];

const priorityStyles: Record<string, string> = {
  High: 'bg-red-500/15 text-red-300 border-red-500/30',
  Medium: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  Low: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
};

const statusStyles: Record<string, string> = {
  Resolved: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  Open: 'bg-yellow-500/15 text-yellow-300 border-yellow-500/30',
  'In Progress': 'bg-blue-500/15 text-blue-300 border-blue-500/30',
  Rejected: 'bg-gray-500/15 text-gray-300 border-gray-500/30',
};

const categoryColors: Record<string, string> = {
  Electrical: '#2563EB',
  Plumbing: '#10B981',
  Furniture: '#F59E0B',
  Civil: '#38BDF8',
  Other: '#A855F7',
  Uncategorized: '#6B7280',
};

export default function MaintenanceDashboard() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [preventive, setPreventive] = useState<{ building_name: string; predicted_category: string; issue_count: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [assignOpenFor, setAssignOpenFor] = useState<number | null>(null);

  const loadAll = useCallback(async () => {
    setError(null);
    try {
      const [feed, s, staffList, prevSuggestions] = await Promise.all([
        getDashboardFeed(),
        getAdminStats(),
        getStaff(),
        getPreventiveSuggestions().catch(() => []),
      ]);
      setComplaints(feed);
      setStats(s);
      setStaff(staffList);
      setPreventive(prevSuggestions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data. Are you logged in as admin?');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  async function handleStatusChange(id: number, status: Complaint['status']) {
    setBusyId(id);
    try {
      await updateComplaintStatus(id, status);
      await loadAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update status');
    } finally {
      setBusyId(null);
    }
  }

  async function handleAnalyze(id: number) {
    setBusyId(id);
    try {
      await triggerAiAnalysis(id);
      await loadAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'AI analysis failed');
    } finally {
      setBusyId(null);
    }
  }

  async function handleAssign(complaintId: number, staffId: number) {
    setBusyId(complaintId);
    try {
      await assignStaffToComplaint(complaintId, staffId);
      setAssignOpenFor(null);
      await loadAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to assign staff');
    } finally {
      setBusyId(null);
    }
  }

  const openCount = stats?.byStatus.find((s) => s.status === 'Open')?.count ?? 0;
  const inProgressCount = stats?.byStatus.find((s) => s.status === 'In Progress')?.count ?? 0;
  const resolvedCount = stats?.byStatus.find((s) => s.status === 'Resolved')?.count ?? 0;

  const summaryCards: SummaryCard[] = [
    {
      icon: ClipboardList,
      value: String(stats?.total ?? 0),
      label: 'Total Issues',
      color: '#2563EB',
      gradient: 'from-blue-600/25 via-blue-500/10 to-transparent',
      border: 'border-blue-500/40',
    },
    {
      icon: Clock,
      value: String(openCount + inProgressCount),
      label: 'Open / In Progress',
      color: '#F59E0B',
      gradient: 'from-yellow-500/25 via-amber-500/10 to-transparent',
      border: 'border-yellow-500/40',
    },
    {
      icon: CheckCircle2,
      value: String(resolvedCount),
      label: 'Resolved',
      color: '#10B981',
      gradient: 'from-emerald-500/25 via-green-500/10 to-transparent',
      border: 'border-emerald-500/40',
    },
    {
      icon: AlertTriangle,
      value: String(stats?.highPriorityOpen ?? 0),
      label: 'Critical Alerts',
      color: '#EF4444',
      gradient: 'from-red-500/25 via-rose-500/10 to-transparent',
      border: 'border-red-500/40',
    },
  ];

  const maxCategoryCount = Math.max(1, ...(stats?.byCategory.map((c) => c.count) ?? [1]));

  return (
    <section id="maintenance" className="relative py-16 sm:py-20 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/5 w-48 sm:w-72 h-48 sm:h-72 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-56 sm:w-80 h-56 sm:h-80 bg-secondary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10 sm:mb-12 lg:mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-1.5 sm:gap-2 px-3 py-1 sm:px-4 sm:py-1.5 rounded-full glass-card text-secondary text-xs sm:text-sm font-medium mb-3 sm:mb-4"
          >
            <HardHat className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            DIET Anakapalli · Live Operations
          </motion.span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-white mb-3 sm:mb-4">
            Campus Maintenance <span className="gradient-text">Dashboard</span>
          </h2>
          <p className="text-sm sm:text-base text-gray-400 max-w-xl lg:max-w-2xl mx-auto px-4">
            Live complaints, AI classification, and staff dispatch — pulled straight from the backend.
          </p>
          <button
            onClick={() => {
              setLoading(true);
              loadAll();
            }}
            className="mt-4 inline-flex items-center gap-1.5 text-xs text-gray-400 hover:text-white transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </motion.div>

        {error && (
          <div className="mb-6 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300 text-center">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-24 text-gray-400 gap-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading live dashboard data...
          </div>
        ) : (
          <>
            {/* Summary cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 mb-8 sm:mb-10">
              {summaryCards.map((card, index) => (
                <motion.div
                  key={card.label}
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  whileHover={{ y: -6, scale: 1.03 }}
                  className="relative group"
                >
                  <div
                    className="absolute -inset-0.5 rounded-xl sm:rounded-2xl blur-lg opacity-0 group-hover:opacity-70 transition-opacity duration-500"
                    style={{ background: `radial-gradient(circle at center, ${card.color}40, transparent 70%)` }}
                  />
                  <div
                    className={`relative glass-card rounded-xl sm:rounded-2xl p-3 sm:p-4 lg:p-5 xl:p-6 bg-gradient-to-br ${card.gradient} border ${card.border} transition-all duration-500 group-hover:border-white/30`}
                    style={{ boxShadow: `0 0 30px ${card.color}15` }}
                  >
                    <div className="flex items-center gap-2 sm:gap-3 mb-2 sm:mb-3 lg:mb-4">
                      <div
                        className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 xl:w-11 xl:h-11 rounded-lg sm:rounded-xl flex items-center justify-center border border-white/10"
                        style={{ background: `${card.color}25` }}
                      >
                        <card.icon className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6" style={{ color: card.color }} />
                      </div>
                      <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-white">{card.value}</p>
                    </div>
                    <p className="text-xs sm:text-sm text-gray-400 font-medium">{card.label}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Requests table */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-5 lg:p-6 mb-8 sm:mb-10 overflow-x-auto"
            >
              <h3 className="font-semibold text-white text-sm sm:text-base mb-4">
                Complaints ({complaints.length})
              </h3>
              {complaints.length === 0 ? (
                <p className="text-sm text-gray-400 py-6 text-center">No complaints submitted yet.</p>
              ) : (
                <table className="w-full text-left min-w-[720px]">
                  <thead>
                    <tr className="border-b border-white/10 text-xs sm:text-sm text-gray-400">
                      <th className="py-2 px-2 sm:px-4 font-medium">ID</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">Location</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">Issue</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">AI</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">Priority</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">Status</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">Staff</th>
                      <th className="py-2 px-2 sm:px-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {complaints.map((c) => (
                      <tr key={c.id} className="border-b border-white/5 last:border-0 align-top">
                        <td className="py-3 px-2 sm:px-4 font-mono text-xs sm:text-sm text-white">CT-{c.id}</td>
                        <td className="py-3 px-2 sm:px-4 text-xs sm:text-sm text-gray-300">
                          {c.building ?? '—'} {c.room ? `· ${c.room}` : ''}
                        </td>
                        <td className="py-3 px-2 sm:px-4 text-xs sm:text-sm text-gray-300 max-w-[220px] truncate" title={c.description}>
                          {c.title}
                        </td>
                        <td className="py-3 px-2 sm:px-4 text-xs sm:text-sm">
                          {c.predicted_category ? (
                            <div className="flex flex-col gap-1">
                              <span className="text-gray-300">{c.predicted_category} · {c.severity}</span>
                              {Boolean(c.is_recurring_issue) && (
                                <span className="inline-flex w-fit items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] border border-orange-500/30 bg-orange-500/10 text-orange-300">
                                  <Sparkles className="w-3 h-3" /> Recurring ×{c.recurring_count}
                                </span>
                              )}
                            </div>
                          ) : (
                            <button
                              disabled={busyId === c.id}
                              onClick={() => handleAnalyze(c.id)}
                              className="text-[11px] text-secondary hover:text-white underline disabled:opacity-50"
                            >
                              {busyId === c.id ? 'Analyzing…' : 'Run AI analysis'}
                            </button>
                          )}
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-medium border ${priorityStyles[c.priority] ?? ''}`}>
                            {c.priority}
                          </span>
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <select
                            value={c.status}
                            disabled={busyId === c.id}
                            onChange={(e) => handleStatusChange(c.id, e.target.value as Complaint['status'])}
                            className={`text-[10px] sm:text-xs font-medium rounded-full border px-2 py-1 bg-transparent outline-none ${statusStyles[c.status] ?? ''}`}
                          >
                            {STATUS_OPTIONS.map((s) => (
                              <option key={s} value={s} className="bg-[#0B1224] text-white">
                                {s}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="py-3 px-2 sm:px-4 text-xs text-gray-300">
                          {c.assigned_staff_name ?? '—'}
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          {assignOpenFor === c.id ? (
                            <select
                              autoFocus
                              disabled={busyId === c.id}
                              defaultValue=""
                              onChange={(e) => e.target.value && handleAssign(c.id, Number(e.target.value))}
                              onBlur={() => setAssignOpenFor(null)}
                              className="text-[11px] rounded-md border border-white/20 bg-[#0B1224] text-white px-2 py-1"
                            >
                              <option value="" disabled>
                                Select staff…
                              </option>
                              {staff.filter((s) => s.is_available).map((s) => (
                                <option key={s.id} value={s.id}>
                                  {s.name} ({s.specialty})
                                </option>
                              ))}
                            </select>
                          ) : (
                            <button
                              onClick={() => setAssignOpenFor(c.id)}
                              className="inline-flex items-center gap-1 text-[11px] text-gray-400 hover:text-white"
                            >
                              <UserPlus className="w-3.5 h-3.5" /> Assign
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </motion.div>

            {/* Category breakdown + preventive suggestions */}
            <div className="grid lg:grid-cols-2 gap-4 sm:gap-6">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-5 lg:p-6"
              >
                <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-secondary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm sm:text-base">Issues by Category</h3>
                    <p className="text-[10px] sm:text-xs text-gray-400">Live breakdown from all complaints</p>
                  </div>
                </div>

                {(!stats || stats.byCategory.length === 0) && (
                  <p className="text-sm text-gray-400">No data yet.</p>
                )}

                <div className="space-y-3 sm:space-y-4 lg:space-y-5">
                  {stats?.byCategory.map((cat, i) => {
                    const color = categoryColors[cat.category] ?? '#6B7280';
                    const percent = Math.round((cat.count / maxCategoryCount) * 100);
                    return (
                      <div key={cat.category}>
                        <div className="flex justify-between text-xs sm:text-sm mb-1.5 sm:mb-2">
                          <span className="text-gray-300">{cat.category}</span>
                          <span className="text-white font-medium">{cat.count}</span>
                        </div>
                        <div className="h-2 sm:h-2.5 rounded-full bg-white/5 overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${percent}%` }}
                            viewport={{ once: true }}
                            transition={{ delay: i * 0.1, duration: 0.8 }}
                            className="h-full rounded-full"
                            style={{ background: color, boxShadow: `0 0 12px ${color}80` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="glass-card rounded-xl sm:rounded-2xl p-4 sm:p-5 lg:p-6"
              >
                <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 rounded-lg bg-secondary/20 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-secondary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm sm:text-base">Preventive Maintenance</h3>
                    <p className="text-[10px] sm:text-xs text-gray-400">AI-flagged repeat problem spots (last 90 days)</p>
                  </div>
                </div>

                {preventive.length === 0 ? (
                  <p className="text-sm text-gray-400">No recurring hotspots detected yet.</p>
                ) : (
                  <div className="space-y-2 sm:space-y-3">
                    {preventive.map((p, i) => (
                      <motion.div
                        key={`${p.building_name}-${p.predicted_category}`}
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.08 }}
                        className="flex items-center justify-between rounded-lg border border-orange-500/20 bg-orange-500/5 px-3 py-2.5"
                      >
                        <div>
                          <p className="text-sm text-white font-medium">{p.building_name}</p>
                          <p className="text-xs text-gray-400">{p.predicted_category} issues recurring</p>
                        </div>
                        <span className="text-sm font-bold text-orange-300">×{p.issue_count}</span>
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
