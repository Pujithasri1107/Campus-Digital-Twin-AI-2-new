import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { submitComplaint, isAuthenticated, getCurrentUser, ApiError } from '../lib/api';

export default function ReportIssue() {
  const user = getCurrentUser();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [building, setBuilding] = useState('');
  const [room, setRoom] = useState('');
  const [photo, setPhoto] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await submitComplaint({ title, description, building, room, photo });
      setSuccess(true);
      setTitle('');
      setDescription('');
      setBuilding('');
      setRoom('');
      setPhoto(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to submit complaint. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section id="report-issue" className="relative py-16 sm:py-20 lg:py-24 overflow-hidden">
      <div className="relative max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8 sm:mb-10"
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-3">
            Report a <span className="gradient-text">Maintenance Issue</span>
          </h2>
          <p className="text-sm sm:text-base text-gray-400">
            Our AI classifies it instantly and routes it to the right team.
          </p>
        </motion.div>

        <div className="glass-card rounded-2xl p-5 sm:p-6 lg:p-8">
          {!isAuthenticated() ? (
            <div className="text-center py-6">
              <p className="text-gray-300 mb-4">Please log in to report an issue.</p>
              <a
                href="#login"
                className="inline-block px-6 py-2.5 rounded-full btn-primary text-white font-medium"
              >
                Log In
              </a>
            </div>
          ) : success ? (
            <div className="text-center py-6">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-3" />
              <p className="text-white font-medium mb-1">Complaint submitted!</p>
              <p className="text-sm text-gray-400 mb-4">Our AI is analyzing it now — the admin team can see it on the dashboard.</p>
              <button
                onClick={() => setSuccess(false)}
                className="text-sm text-secondary hover:text-white underline"
              >
                Report another issue
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-xs text-gray-400">Reporting as {user?.name}</p>

              {error && (
                <div className="flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs sm:text-sm text-gray-400 mb-1.5 font-medium">Title</label>
                <input
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Fan not working"
                  className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 border border-white/10 focus:outline-none focus:border-secondary/60"
                />
              </div>

              <div>
                <label className="block text-xs sm:text-sm text-gray-400 mb-1.5 font-medium">Description</label>
                <textarea
                  required
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the issue in detail..."
                  className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 border border-white/10 focus:outline-none focus:border-secondary/60 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs sm:text-sm text-gray-400 mb-1.5 font-medium">Building</label>
                  <input
                    required
                    value={building}
                    onChange={(e) => setBuilding(e.target.value)}
                    placeholder="e.g. CSE Block"
                    className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 border border-white/10 focus:outline-none focus:border-secondary/60"
                  />
                </div>
                <div>
                  <label className="block text-xs sm:text-sm text-gray-400 mb-1.5 font-medium">Room (optional)</label>
                  <input
                    value={room}
                    onChange={(e) => setRoom(e.target.value)}
                    placeholder="e.g. 204"
                    className="w-full bg-white/5 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 border border-white/10 focus:outline-none focus:border-secondary/60"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs sm:text-sm text-gray-400 mb-1.5 font-medium">Photo (optional)</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
                  className="w-full text-xs text-gray-400 file:mr-3 file:px-4 file:py-2 file:rounded-lg file:border-0 file:bg-white/10 file:text-white file:text-xs"
                />
              </div>

              <motion.button
                type="submit"
                disabled={submitting}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full flex items-center justify-center gap-2 rounded-xl py-3.5 font-semibold text-white btn-primary disabled:opacity-60"
              >
                {submitting ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                {submitting ? 'Submitting...' : 'Submit Complaint'}
              </motion.button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
