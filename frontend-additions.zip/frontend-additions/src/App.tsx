import { useEffect, useState } from 'react';
import Navbar from './components/ui/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import CampusMap from './components/CampusMap';
import AIAssistant from './components/AIAssistant';
import ReportIssue from './components/ReportIssue';
import MaintenanceDashboard from './components/MaintenanceDashboard';
import Analytics from './components/Analytics';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Login from './components/Login';
import { getCurrentUser, isAuthenticated, clearSession } from './lib/api';

function App() {
  const [mounted, setMounted] = useState(false);
  const [currentPage, setCurrentPage] = useState<'home' | 'login'>('home');

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (hash === 'login') {
        setCurrentPage('login');
      } else {
        setCurrentPage('home');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  if (!mounted) {
    return (
      <div style={{ minHeight: '100vh', backgroundColor: '#050B1A', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: '32px', height: '32px', border: '2px solid #2563EB', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (currentPage === 'login') {
    return <Login />;
  }

  const user = getCurrentUser();
  const isAdmin = isAuthenticated() && user?.role === 'admin';

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#050B1A', color: 'white' }}>
      <Navbar />
      <main>
        <Hero />
        <Features />
        <CampusMap />
        <AIAssistant />
        <ReportIssue />
        {isAdmin ? (
          <>
            <MaintenanceDashboard />
            <Analytics />
          </>
        ) : (
          <section id="maintenance" className="relative py-16 sm:py-20 lg:py-24 text-center px-4">
            <div id="dashboard" className="glass-card max-w-md mx-auto rounded-2xl p-8">
              <p className="text-white font-medium mb-2">Admin Dashboard</p>
              <p className="text-sm text-gray-400 mb-5">
                {isAuthenticated()
                  ? 'This account is not an admin account.'
                  : 'Log in with an admin account to view live maintenance data and analytics.'}
              </p>
              {!isAuthenticated() && (
                <a href="#login" className="inline-block px-6 py-2.5 rounded-full btn-primary text-white font-medium">
                  Admin Login
                </a>
              )}
            </div>
          </section>
        )}
        <Contact />
      </main>
      {isAuthenticated() && (
        <div className="text-center pb-6">
          <button
            onClick={() => {
              clearSession();
              window.location.hash = 'home';
              window.location.reload();
            }}
            className="text-xs text-gray-500 hover:text-gray-300 underline"
          >
            Log out ({user?.name})
          </button>
        </div>
      )}
      <Footer />
    </div>
  );
}

export default App;
