// Base URL of Member 2's Node/Express backend.
// Set VITE_API_URL in a .env file when deploying; defaults to local dev.
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'student' | 'admin';
}

export interface Complaint {
  id: number;
  title: string;
  description: string;
  building: string | null;
  room: string | null;
  photo_path: string | null;
  status: 'Open' | 'In Progress' | 'Resolved' | 'Rejected';
  priority: 'Low' | 'Medium' | 'High';
  category: string;
  created_at: string;
  updated_at: string;
  predicted_category?: string | null;
  severity?: 'Minor' | 'Moderate' | 'Severe' | null;
  confidence_score?: number | null;
  is_recurring_issue?: 0 | 1 | null;
  recurring_count?: number | null;
  ai_notes?: string | null;
  assignment_id?: number | null;
  assigned_to?: number | null;
  assigned_staff_name?: string | null;
  assignment_completed_at?: string | null;
}

export interface AdminStats {
  total: number;
  highPriorityOpen: number;
  byStatus: { status: string; count: number }[];
  byCategory: { category: string; count: number }[];
  byPriority: { priority: string; count: number }[];
  mostAffectedBuildings: { building: string; count: number }[];
}

export interface StaffMember {
  id: number;
  name: string;
  email: string;
  specialty: string;
  is_available: 0 | 1;
}

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

function getToken(): string | null {
  return localStorage.getItem('cdt_token');
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const isFormData = options.body instanceof FormData;

  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok || data.success === false) {
    throw new ApiError(data.message || `Request failed (${res.status})`, res.status);
  }

  return data as T;
}

// ---- Auth ----

export function saveSession(token: string, user: User) {
  localStorage.setItem('cdt_token', token);
  localStorage.setItem('cdt_user', JSON.stringify(user));
}

export function clearSession() {
  localStorage.removeItem('cdt_token');
  localStorage.removeItem('cdt_user');
}

export function getCurrentUser(): User | null {
  const raw = localStorage.getItem('cdt_user');
  return raw ? JSON.parse(raw) : null;
}

export function isAuthenticated(): boolean {
  return Boolean(getToken());
}

export async function loginUser(email: string, password: string) {
  const data = await request<{ token: string; user: User }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  saveSession(data.token, data.user);
  return data.user;
}

export async function registerUser(name: string, email: string, password: string, role: 'student' | 'admin' = 'student') {
  const data = await request<{ token: string; user: User }>('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password, role }),
  });
  saveSession(data.token, data.user);
  return data.user;
}

// ---- Complaints ----

export async function submitComplaint(payload: {
  title: string;
  description: string;
  building?: string;
  room?: string;
  photo?: File | null;
}) {
  const form = new FormData();
  form.append('title', payload.title);
  form.append('description', payload.description);
  if (payload.building) form.append('building', payload.building);
  if (payload.room) form.append('room', payload.room);
  if (payload.photo) form.append('photo', payload.photo);

  const data = await request<{ complaint: Complaint }>('/api/complaints', {
    method: 'POST',
    body: form,
  });
  return data.complaint;
}

export async function getMyComplaints() {
  const data = await request<{ complaints: Complaint[] }>('/api/complaints');
  return data.complaints;
}

// ---- Admin dashboard ----

export async function getDashboardFeed() {
  const data = await request<{ complaints: Complaint[] }>('/api/admin/dashboard-feed');
  return data.complaints;
}

export async function getAdminStats() {
  const data = await request<{ stats: AdminStats }>('/api/admin/stats');
  return data.stats;
}

export async function updateComplaintStatus(id: number, status: Complaint['status']) {
  const data = await request<{ complaint: Complaint }>(`/api/complaints/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
  return data.complaint;
}

export async function triggerAiAnalysis(complaintId: number) {
  const data = await request<{ analysis: unknown; aiServiceReachable: boolean }>(
    `/api/ai/analyze/${complaintId}`,
    { method: 'POST' }
  );
  return data;
}

export async function getPreventiveSuggestions() {
  const data = await request<{ suggestions: { building_name: string; predicted_category: string; issue_count: number }[] }>(
    '/api/ai/preventive'
  );
  return data.suggestions;
}

// ---- Staff dispatch ----

export async function getStaff(params?: { specialty?: string; available?: boolean }) {
  const qs = new URLSearchParams();
  if (params?.specialty) qs.set('specialty', params.specialty);
  if (params?.available !== undefined) qs.set('available', String(params.available));
  const suffix = qs.toString() ? `?${qs}` : '';
  const data = await request<{ staff: StaffMember[] }>(`/api/staff${suffix}`);
  return data.staff;
}

export async function assignStaffToComplaint(complaintId: number, staffId: number, remarks?: string) {
  const data = await request<{ assignment: unknown }>(`/api/complaints/${complaintId}/assign`, {
    method: 'POST',
    body: JSON.stringify({ staffId, remarks }),
  });
  return data.assignment;
}

export { API_URL, ApiError };
